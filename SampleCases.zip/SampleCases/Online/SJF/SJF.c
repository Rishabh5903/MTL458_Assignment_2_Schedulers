#include "../../online_schedulers.h"

int main(){
    ShortestJobFirst();
}